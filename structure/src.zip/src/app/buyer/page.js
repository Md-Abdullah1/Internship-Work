import React from 'react'

const page = () => {
  return (
    <div>
      Buyer
    </div>
  )
}

export default page